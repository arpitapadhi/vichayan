<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vichayan</title>
    <link rel="icon" href="pic/bg22.png">

    <!-- google fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:ital@0;1&display=swap" rel="stylesheet">

    <!-- bootstrap -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

    <!-- Main Style -->
    <link rel="stylesheet" href="mycss.css">

</head>

<link rel="stylesheet" href="style90.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css"/>


  <input type="checkbox" id="toggle">
  <label for="toggle" class="show-btn">Show Modal</label>
  <div class="wrapper">
    <label for="toggle">
    <i class="cancel-icon fas fa-times"></i>
    </label>
    <div class="icon"><i class="far fa-envelope"></i></div>
    <div class="content">
      <header>Be a part of us, Be a Subscriber</header>
      <p>Subscribe to our blog and get the latest updates straight to your inbox.</p>
    </div>
    <form action="myHtml.php" method="POST">
      <?php 
      $userEmail = ""; //first we leave email field blank
      if(isset($_POST['subscribe'])){ //if subscribe btn clicked
        $userEmail = $_POST['email']; //getting user entered email
        if(filter_var($userEmail, FILTER_VALIDATE_EMAIL)){ //validating user email
          $subject = "Thanks for Subscribing us - vichayan";
          $message = "Thanks for subscribing to our blog. You'll always receive updates from us. And we won't share and sell your information.";
          $sender = "From: padhiarpita1998@gmail.com";
          //php function to send mail
          if(mail($userEmail, $subject, $message, $sender)){
            ?>
             <!-- show sucess message once email send successfully -->
            <div class="alert success-alert">
              <?php echo "Thanks for Subscribing us." ?>
            </div>
            <?php
            $userEmail = "";
          }else{
            ?>
            <!-- show error message if somehow mail can't be sent -->
            <div class="alert error-alert">
            <?php echo "Failed while sending your mail!" ?>
            </div>
            <?php
          }
        }else{
          ?>

          <!-- show error message if user entered email is not valid -->
          <div class="alert error-alert">
            <?php echo "$userEmail is not a valid email address!" ?>
          </div>
          <?php
        }
      }
      ?>
      
      <div class="field">
        <input type="text" class="Name" name="Name" placeholder="Enter Name" required value=""><br><br>
        <input type="text" class="Email" name="Email" placeholder="Email Address" required value=""><br><br>
        
      </div>
      <br>
      <br>
      <br>
      <div class="field btn">
        <div class="layer"></div>
        <button type="submit" name="subscribe">Subscribe</button>
      </div>
    </form>
    <div class="text">We do not share your information.</div>
  </div>



    <!------------------ navbar ------------------->

    <section id="nav-bar">
        <nav class="navbar navbar-expand-lg navbar-light">
            <a class="navbar-brand" href="#"><img src="pic/bg22.png" alt="" class="img-responsive logo"></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
              <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
              <ul class="navbar-nav ml-auto">
                  <li class="nav-item ">
                    <a class="nav-link"><button class="btn  btx1 text-center" type="button">Join Free</button></a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link"><button class="btn  btx1 text-center" type="button">Sign In</button></a>
                  </li>
              </ul>
           </div>
        </nav>
        </section>
    <!------------------ end of navbar------------------>

    <!------------------ header ------------------>

    <div class="header">
        <div class="hh1">
            <img src="pic/bg1.jpg" alt="">
        </div>
        <div class="hh2">
            <div><img class="p1" src="pic/bg11.jpeg" alt=""></div>
            <div>
        
                <h1>
                    Are you looking <br>
                    for research <br>
                    colleagues ? <br>
                </h1>
                <div class="buttons">
                    <div><button type="button" class="btn ">Join Free</button>
                    </div>
                    <div><button type="button" class="btn ">Sign In</button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!------------------ end of header ------------------>

    <!------------------ body section ------------------>

    <!-- c1 used for research section -->
    <div class="c1">
        <h1>Scrutinize with us to broden your <br>
            knowledge to accelarate innovation</h1>
        <button type="button" class="btn btn-lg">Research Now</button>
    </div>
    <!-- c2 & c3 both are used for below section of research section -->
    <div class="c2">
        <div>
            <h1>Make Research <br>
                Easy With <br>
                Vichayan</h1>
        </div>
        <div class="img1">
            <img src="pic/bg9.png" alt="">
        </div>
    </div>
    
        </div>
    </div>

    <!------------------ end of body Section  ------------------>

    <!------------------ footer ------------------>

    <footer>
        <div class="myfooter">
            <div class="img"><img src="pic/bg22.png" alt=""></div>
            <div class="text">
                <ul>
                    <h3>Service</h3>
                    <li><a href="#">Research Assitance</a></li>
                    <li><a href="#">Self Article Publishing </a></li>
                    <li><a href="#">Self Book Publishing </a></li>
                    <li><a href="#">Get Hired </a></li>
                    <li><a href="#">Get Skilled </a></li>
                </ul>
            </div>
            <div class="text">
                <ul>
                    <h3>Business</h3>
                    <li><a href="#">Publisher Hub </a></li>
                    <li><a href="#">Univesity Lab </a></li>
                    <li><a href="#">Recuter Hub </a></li>
                    <li><a href="#">Learning Hub </a></li>
                    <li><a href="#">Research Organisation </a></li>
                    <li><a href="#">Business Organisation </a></li>
                </ul>
            </div>
            <div class="text">
                <ul>
                    <h3>Company</h3>
                    <li><a href="#">Vichayan </a></li>
                    <li><a href="#">Investor Relation </a></li>
                    <li><a href="#">Blog </a></li>
                    <li><a href="#">Press </a></li>
                </ul>
            </div>
        </div>

        <p class="copyright">
            User Agreements | Privacy Policy | Cokie Policy | Copyright Policy | Brand Policy | Community
            Guideline <br>
            © 2021 Tanumanasa Service Private Limited . All rights reserved.
        </p>
    </footer>

    <!------------------ end of footer -------------------->

</body>

</html>