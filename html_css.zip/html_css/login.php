<?php
//start the session
session_start();
?>
<?php
      $emailErr=$passErr="";
      $email=$pass="";
      $status=true;
	  //check if form submittes or not
      if(!empty($_POST)) {
			if(empty($_POST['email'])){
				$status=false;
				$emailErr="Email Required";
	
			} else {
				   $email=$_POST['email'];
			
			}
			if(empty($_POST['pass'])){
				$status=false;
				$passErr="password required";
			} else {
				$pass=$_POST['pass'];
			}
			$servername="localhost";
	        $username="root";
	        $password="";
	        $dbname="blog";
			//check for the validation status
	        if($status){
		        $conn=new mysqli($servername,$username,$password,$dbname);
				// check connection
				if($conn->connect_error){
						die("connection failed:" . $conn->connect_error);
				}
				$pass=sha1($pass);
				$sql = "SELECT id,first_name,last_name,email FROM name WHERE email='$email' and password='$pass'";
				$result = $conn->query($sql);
				//check if email exists
				if ($result->num_rows > 0 ) {
					 //converting the result to associative array 
					 $record =$result->fetch_assoc(); 		
					 $_SESSION['loggedIn'] = true;
					 $_SESSION['userDetails'] = $record;
					 header('location: profile5.php');
				} else {
					echo "invalid username or password";
				}
				//close the DB connection
				$conn->close();
			}
	  }
?>	  

	
   