
       
<?php
$fnameErr = $lnameErr =$emailErr =$passErr="";
$fname= $lname =$email=$pass="";
$status=true;
//check if form submitted or not
if(!empty($_POST)) {
	    if(empty($_POST['fname'])){
                 $fnameErr="First name required";
		         $status=false;
		
		} else {
			   $fname=$_POST['fname'];
		}
		if(empty($_POST['lname'])){
			$status=false;
			$lnameErr="last name required";
		}
		else {
			   $lname=$_POST['lname'];
		}
		if(empty($_POST['email'])){
			  $status=false;
			  $emailErr="Email required";
		} else {
			   $email=$_POST['email'];
		}
		if(empty($_POST['pass1'])){
			   $status=false;
			   $passErr="password Required";
		} else {
			   $pass=$_POST['pass1'];
		}
		//file related code
		$target_dir = "uploads/";
		$target_file = $target_dir.basename($_FILES["profileimage"]["name"]);
		$filestatus = true;
		//get the image extension
		$imageFiletype = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
		if($imageFiletype !="jpg" && $imageFiletype !="png") {
			$fileErr="only JPG and PNG images allowed";
			$fileststus= false;
			$status= false;
		}
		if ($filestatus){
				if(move_uploaded_file($_FILES["profileimage"]["tmp_name"],$target_file)) {
				$status = true;
		//die("File uploaded");
				}else{
					$fileErr="Issues in file upload";
					$status=false;
				}
		}
		
	
		$servername="localhost";
		$username="root";
		$password="";
		$dbname="blog";
		//check for the validation status
		if($status){
			$conn=new mysqli($servername,$username,$password,$dbname);
			// check connection
			if($conn->connect_error){
				die("connection failed: " . $conn->connect_error);
			}
			$sql = "SELECT * FROM users WHERE email='$email'";
			$result = $conn->query($sql);
			//check if email exists
			if ($result->num_rows > 0){
				$emailErr="Email already exist. please login to continue";
			}else{
				//encrypt the password
				$pass = sha1($pass);
				//insert in DB
				$sql= "INSERT INTO name (first_name,last_name,email,password, image)
				values('$fname','$lname','$email','$pass','$target_file')";
				
				if($conn->query($sql)=== true) {
					header('Location: login.php');
				}else{
					echo "Error:".$sql."<br>".$conn->error;
				}
			}
					//close the DB connection
				$conn->close();
		}
	}
?>
